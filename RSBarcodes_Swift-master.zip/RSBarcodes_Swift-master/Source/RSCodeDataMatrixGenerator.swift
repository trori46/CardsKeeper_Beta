//
//  RSCodeDataMatrixGenerator.swift
//  RSBarcodes
//
//  Created by R0CKSTAR on 15/10/26.
//  Copyright (c) 2015 P.D.Q. All rights reserved.
//

import UIKit

class RSCodeDataMatrixGenerator: RSAbstractCodeGenerator {

}
